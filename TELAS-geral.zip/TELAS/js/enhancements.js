// Complementos funcionais do protótipo: evidências, assinaturas e configurações locais.
const originalRender = render;
const originalFormMarkup = originalFormPage;
const originalSaveRecord = saveRecord;
const originalConfigMarkup = configPage;
const originalDetailMarkup = recordDetail;

state.evidence = [];
state.signatures = {};
state.evidenceBusy = 0;
state.settings = saved.settings || {};
if (state.settings.checklists?.length) CONFIG.checklist = state.settings.checklists;
if (state.settings.municipio?.nome) CONFIG.municipio.nome = state.settings.municipio.nome;

function enhancementSlug(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function enhancementSignature(label) {
  const id = `signature-${enhancementSlug(label)}`;
  return `<div class="signature-wrap"><canvas class="signature-canvas" id="${id}" aria-label="Assinatura: ${escapeHtml(label)}"></canvas><div class="signature-tools"><span>Assine com o dedo ou mouse</span><button type="button" class="button small ghost" data-action="clear-signature" data-signature="${id}">Limpar</button></div></div>`;
}

function enhancementEvidenceMarkup() {
  if (!state.evidence.length) return '<div class="evidence-empty">Nenhuma evidência adicionada.<br>Fotos e documentos selecionados ficarão vinculados ao registro salvo.</div>';
  return `<div class="evidence-list">${state.evidence.map((file, index) => `<div class="evidence-item">${file.type.startsWith('image/') ? `<img src="${file.data}" alt="Prévia de ${escapeHtml(file.name)}">` : `<span class="evidence-file-icon">${file.type === 'application/pdf' ? 'PDF' : 'DOC'}</span>`}<div class="evidence-file-info"><strong>${escapeHtml(file.name)}</strong><small>${(file.size / 1024).toFixed(0)} KB</small>${file.type === 'application/pdf' ? `<a href="${file.data}" target="_blank" rel="noopener">Abrir PDF</a>` : ''}</div><button type="button" class="button small danger" data-action="remove-evidence" data-index="${index}" aria-label="Remover ${escapeHtml(file.name)}">Remover</button></div>`).join('')}</div>`;
}
function evidenceMarkup() { return enhancementEvidenceMarkup(); }

function enhancementAttachSignature(html, label) {
  const id = `signature-${enhancementSlug(label)}`;
  const signature = state.signatures[id];
  return `<div class="signature-wrap"><canvas class="signature-canvas" id="${id}" aria-label="Assinatura: ${escapeHtml(label)}" data-saved-signature="${signature || ''}"></canvas><div class="signature-tools"><span>Assine com o dedo ou mouse</span><button type="button" class="button small ghost" data-action="clear-signature" data-signature="${id}">Limpar</button></div></div>`;
}

function setupSignatureCanvases() {
  document.querySelectorAll('.signature-canvas').forEach(canvas => {
    const box = canvas.getBoundingClientRect();
    if (!box.width) return;
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.round(box.width * ratio);
    canvas.height = Math.round(130 * ratio);
    canvas.style.height = '130px';
    const ctx = canvas.getContext('2d');
    ctx.scale(ratio, ratio);
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#17252e';
    const prior = canvas.dataset.savedSignature || state.signatures[canvas.id];
    if (prior) {
      const image = new Image();
      image.onload = () => ctx.drawImage(image, 0, 0, box.width, 130);
      image.src = prior;
    }
    let drawing = false;
    const point = event => {
      const rect = canvas.getBoundingClientRect();
      return { x: event.clientX - rect.left, y: event.clientY - rect.top };
    };
    canvas.addEventListener('pointerdown', event => {
      event.preventDefault();
      drawing = true;
      canvas.setPointerCapture(event.pointerId);
      const p = point(event);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + 0.1, p.y + 0.1);
      ctx.stroke();
    });
    canvas.addEventListener('pointermove', event => {
      if (!drawing) return;
      const p = point(event);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    });
    const finish = () => {
      if (!drawing) return;
      drawing = false;
      state.signatures[canvas.id] = canvas.toDataURL('image/png');
    };
    canvas.addEventListener('pointerup', finish);
    canvas.addEventListener('pointercancel', finish);
  });
}

originalFormPage = function (kind) {
  let html = originalFormMarkup(kind);
  html = html.replace(/<div class="signature">Área para assinatura no dispositivo<\/div>/g, enhancementSignature('Agente'));
  html = html.replace(/<div class="signature">Área para assinatura<\/div>/g, enhancementSignature('Responsável'));
  html = html.replace(/<div class="signature">Área para assinatura do vistoriado<\/div>/g, enhancementSignature('Vistoriado'));
  html = html.replace(/<div class="evidence-empty">Nenhuma evidência adicionada\.<br>Arquivos poderão ser vinculados ao registro\.<\/div>/g, enhancementEvidenceMarkup());
  return html;
};

formPage = function (kind) {
  let html = originalFormPage(kind);
  html = html.replace(/<div class="signature">Área para assinatura no dispositivo<\/div>/g, enhancementSignature('Agente'));
  html = html.replace(/<div class="signature">Área para assinatura<\/div>/g, enhancementSignature('Responsável'));
  html = html.replace(/<div class="signature">Área para assinatura do vistoriado<\/div>/g, enhancementSignature('Vistoriado'));
  html = html.replace(/<div class="evidence-empty">Nenhuma evidência adicionada\.<br>Arquivos poderão ser vinculados ao registro\.<\/div>/g, enhancementEvidenceMarkup());
  return html;
};

function enhancementConfigPage(page) {
  const titles = {
    'config-municipio': ['Município e identidade visual', 'Edite as informações que identificam a prefeitura.'],
    'config-secretarias': ['Secretarias', 'Mantenha uma unidade por linha.'],
    'config-departamentos': ['Departamentos e setores', 'Mantenha um departamento ou setor por linha.'],
    'config-tipos': ['Tipos de registro', 'Mantenha um tipo de registro por linha.'],
    'config-checklists': ['Checklists', 'Mantenha um item de vistoria por linha.'],
    'config-perfis': ['Perfis e permissões', 'Mantenha um perfil de acesso por linha.'],
    'config-documentos': ['Documentos e tags', 'Mantenha uma categoria ou tag por linha.']
  };
  if (!titles[page]) return originalConfigMarkup(page);
  const [title, description] = titles[page];
  const key = page.replace('config-', '');
  let initial = state.settings[key];
  if (initial === undefined) {
    if (page === 'config-municipio') initial = { nome: CONFIG.municipio.nome, cnpj: '', endereco: '' };
    else if (page === 'config-secretarias') initial = ['Trânsito', 'Obras', 'Serviços Urbanos', 'Meio Ambiente', 'Administração', 'Saúde', 'Educação'];
    else if (page === 'config-checklists') initial = CONFIG.checklist;
    else initial = [];
  }
  const fields = page === 'config-municipio'
    ? `<div class="fields"><div class="field"><label for="setting-nome">Nome do município</label><input id="setting-nome" value="${escapeHtml(initial.nome || '')}"></div><div class="field"><label for="setting-cnpj">CNPJ</label><input id="setting-cnpj" value="${escapeHtml(initial.cnpj || '')}"></div><div class="field full"><label for="setting-endereco">Endereço</label><input id="setting-endereco" value="${escapeHtml(initial.endereco || '')}"></div></div>`
    : `<div class="field"><label for="setting-list">Itens (um por linha)</label><textarea id="setting-list" rows="12">${escapeHtml(initial.join('\n'))}</textarea></div>`;
  return `<div class="pagehead"><div><p class="eyebrow">Configurações</p><h1>${title}</h1><p class="subhead">${description}</p></div>${btn('← Voltar às configurações', 'configuracoes', 'ghost')}</div><article class="card form-section">${fields}<div class="form-actions" style="margin-top:18px">${btn('Salvar configuração', 'save-config')}</div><p class="stat-note">As alterações são salvas neste navegador e não sincronizam com outros aparelhos.</p></article>`;
}

configPage = enhancementConfigPage;
recordDetail = function (history = false) {
  let html = originalDetailMarkup(history);
  if (history) return html;
  const id = new URLSearchParams(location.search).get('id');
  const record = state.records.find(item => item.number === id);
  if (!record) return html;
  const evidence = (record.evidence || []).map(file => `<div class="evidence-item">${file.type.startsWith('image/') ? `<img src="${file.data}" alt="${escapeHtml(file.name)}">` : '<span class="evidence-file-icon">DOC</span>'}<div class="evidence-file-info"><strong>${escapeHtml(file.name)}</strong><small>${(file.size / 1024).toFixed(0)} KB</small>${file.type === 'application/pdf' ? `<a href="${file.data}" target="_blank" rel="noopener">Abrir PDF</a>` : ''}</div></div>`).join('');
  const signatures = Object.entries(record.signatures || {}).map(([name, image]) => `<div class="saved-signature"><strong>${escapeHtml(name.replace('signature-', '').replaceAll('-', ' '))}</strong><img src="${image}" alt="Assinatura salva"></div>`).join('');
  if (!evidence && !signatures) return html;
  return html.replace('</article>', `<section class="card-body saved-proof"><h2>Evidências e assinaturas</h2>${evidence ? `<div class="evidence-list">${evidence}</div>` : ''}${signatures ? `<div class="saved-signatures">${signatures}</div>` : ''}</section></article>`);
};
render = function () {
  originalRender();
  setupSignatureCanvases();
};

async function shrinkEvidence(file) {
  if (!file.type.startsWith('image/')) {
    if (file.size > 1_200_000) throw new Error('Documentos precisam ter até 1,2 MB.');
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ name: file.name, type: file.type, size: file.size, data: reader.result });
      reader.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
      reader.readAsDataURL(file);
    });
  }
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const data = canvas.toDataURL('image/jpeg', 0.72);
  const size = Math.ceil((data.length - data.indexOf(',') - 1) * 0.75);
  if (size > 900_000) throw new Error('A imagem ainda ficou grande. Escolha uma foto menor.');
  return { name: file.name, type: 'image/jpeg', size, data };
}

document.addEventListener('change', async event => {
  const input = event.target.closest('#content input[type="file"]');
  if (!input || !input.files?.length) return;
  const files = [...input.files];
  input.value = '';
  state.evidenceBusy += 1;
  for (const file of files) {
    try {
      if (state.evidence.length >= 20) throw new Error('Limite de 20 evidências por registro.');
      const item = await shrinkEvidence(file);
      const bytes = state.evidence.reduce((sum, x) => sum + x.size, 0) + item.size;
      if (bytes > 2_500_000) throw new Error('Limite local de 2,5 MB de evidências por registro.');
      state.evidence.push(item);
    } catch (error) {
      toast(error.message || 'Falha ao adicionar evidência.');
    }
  }
  state.evidenceBusy = Math.max(0, state.evidenceBusy - 1);
  render();
}, true);

document.addEventListener('click', event => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  if (button.dataset.action === 'remove-evidence') {
    event.stopImmediatePropagation();
    state.evidence.splice(Number(button.dataset.index), 1);
    render();
  } else if (button.dataset.action === 'clear-signature') {
    event.stopImmediatePropagation();
    const id = button.dataset.signature;
    delete state.signatures[id];
    const canvas = document.getElementById(id);
    if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
  } else if (button.dataset.action === 'save-config') {
    event.stopImmediatePropagation();
    const page = state.page;
    const key = page.replace('config-', '');
    if (page === 'config-municipio') {
      state.settings[key] = {
        nome: document.querySelector('#setting-nome').value.trim(),
        cnpj: document.querySelector('#setting-cnpj').value.trim(),
        endereco: document.querySelector('#setting-endereco').value.trim()
      };
      if (state.settings[key].nome) CONFIG.municipio.nome = state.settings[key].nome;
    } else {
      const list = document.querySelector('#setting-list').value.split('\n').map(x => x.trim()).filter(Boolean);
      if (!list.length) { toast('Informe pelo menos um item.'); return; }
      state.settings[key] = list;
      if (page === 'config-checklists') CONFIG.checklist = list;
    }
    try {
      localStorage.setItem('plataforma-municipal', JSON.stringify({ records: state.records, users: state.users, settings: state.settings }));
      localStorage.setItem('plataforma-config', JSON.stringify(state.settings));
      toast('Configuração salva neste navegador.');
      render();
    } catch {
      toast('Não foi possível salvar. O armazenamento local pode estar cheio.');
    }
  }
}, true);

saveRecord = function (mode = 'complete') {
  if (state.evidenceBusy) { toast('Aguarde o processamento das evidências antes de salvar.'); return; }
  collectForm();
  const kind = state.page.slice(4);
  const prefix = { vistoria: 'VIS', fiscalizacao: 'FIS', ocorrencia: 'OCO', recolhimento: 'REC', apreensao: 'APR', solicitacao: 'SOL', protocolo: 'PRO', processo: 'PRC' }[kind] || 'REG';
  const date = new Date();
  const destination = { vistoria: 'vistorias', fiscalizacao: 'fiscalizacoes', ocorrencia: 'ocorrencias', recolhimento: 'recolhimentos', apreensao: 'apreensoes', solicitacao: 'solicitacoes', protocolo: 'protocolos', processo: 'processos' }[kind] || 'consultas';
  const subject = ({ vistoria: state.form['f-tipo-de-vistoria'] || 'Vistoria', fiscalizacao: state.form['f-tipo-de-fiscalizacao'] || 'Fiscalização de campo', ocorrencia: state.form['f-tipo-de-ocorrencia'] || 'Boletim de ocorrência', recolhimento: 'Itens / objetos', apreensao: 'Registro de apreensão', solicitacao: state.form['f-assunto'] || 'Solicitação de serviço', protocolo: 'Protocolo municipal', processo: state.form['f-assunto'] || 'Processo administrativo' })[kind] || 'Novo registro';
  const number = `${prefix}-${date.getFullYear()}-${String(490 + state.records.length).padStart(5, '0')}`;
  const record = {
    number,
    kind: pages[destination] || 'Registro',
    subject,
    place: state.form['f-endereco'] || state.form['f-local'] || 'A preencher',
    agent: CONFIG.usuario.nome,
    date: date.toLocaleDateString('pt-BR'),
    status: mode === 'draft' ? 'Rascunho' : mode === 'complete' ? 'Concluído' : 'Em andamento',
    data: { ...state.form },
    evidence: [...state.evidence],
    signatures: { ...state.signatures }
  };
  state.records.unshift(record);
  try {
    localStorage.setItem('plataforma-municipal', JSON.stringify({ records: state.records, users: state.users, settings: state.settings }));
    state.form = {};
    state.draftItems = [];
    state.evidence = [];
    state.signatures = {};
    state.formStage = 'entry';
    toast(mode === 'draft' ? 'Rascunho salvo.' : 'Registro finalizado e salvo.');
    setPage(destination);
  } catch {
    state.records.shift();
    toast('Não foi possível salvar. O espaço local pode estar cheio; remova anexos e tente novamente.');
  }
};

render();
