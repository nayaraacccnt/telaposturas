// Edite aqui as informações e listas exibidas pela plataforma.
window.CONFIG = {
  municipio: { nome: 'São Luís · MA' },
  usuario: {
    nome: 'Agente David Matos',
    matricula: '438936-01',
    cargo: 'Agente de Fiscalização'
  },
  leis: [
    { titulo: 'Lei 9.520', subtitulo: 'Fretamento', cor: 'blue' },
    { titulo: 'Lei 14.791', subtitulo: 'Escolar', cor: 'green' },
    { titulo: 'Lei 14.158', subtitulo: 'Táxi', cor: 'red' },
    { titulo: 'Lei 3.060', subtitulo: 'Transporte Coletivo · TCU', cor: 'gray' },
    { titulo: 'Clandestino', subtitulo: '', cor: 'purple' },
    { titulo: 'Registro de Infração', subtitulo: '', cor: 'red' },
    { titulo: 'Lei 252', subtitulo: 'Código de Posturas', cor: 'blue' },
    { titulo: 'Lei 2.943', subtitulo: 'Cerol', cor: 'green' },
    { titulo: 'Lei 3.104', subtitulo: 'Limpeza de Lotes', cor: 'red' },
    { titulo: 'Lei 3.105', subtitulo: 'Entulhos', cor: 'yellow' },
    { titulo: 'Lei 3.124', subtitulo: 'Lei do Bar', cor: 'cyan' },
    { titulo: 'Lei 3.158', subtitulo: 'Estradas Municipais', cor: 'dark' }
  ],
  taloes: [
    'Notificação Preliminar',
    'Constatação',
    'Lacração',
    'Apreensão',
    'Imposição de Multa'
  ],
  checklist: [
    'Luz de placa / ré', 'Placa', 'Iluminação interna', 'Faróis',
    'Quantidade de bancos', 'Sistema de iluminação/sinalização', 'Pneus',
    'Extintor', 'Condições gerais', 'Inscrições obrigatórias', 'Limpeza',
    'Espaçamento máximo do vidro', 'Câmera/monitor', 'Cinto de segurança',
    'Buzina', 'Adesivos obrigatórios', 'Bancos', 'Tacógrafo', 'Setas',
    'Sonoro parada obrigatória/campainha', 'Equipamentos obrigatórios',
    'Sonoro de ré'
  ]
};
